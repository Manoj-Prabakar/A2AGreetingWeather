import json
import requests

def fetch_purchase_data_from_s3(bucket_name, file_key, aws_access_key_id, aws_secret_access_key):
    try:
        # Construct the URL for the S3 object
        url = f"https://{bucket_name}.s3.amazonaws.com/{file_key}"
        
        # Make a GET request to fetch data from S3
        response = requests.get(url, auth=(aws_access_key_id, aws_secret_access_key))
        
        # Check if the request was successful (status code 200)
        if response.status_code == 200:
            return json.loads(response.text)
        else:
            print(f"Error: Failed to fetch data from S3. Status code: {response.status_code}")
            return None
    except Exception as e:
        print(f"Error fetching data from S3: {e}")
        return None

def calculate_total_products_per_customer(purchase_data):
    # Dictionary to store total number of products purchased by each customer
    total_products_per_customer = {}

    # Iterate through each purchase record
    for purchase in purchase_data['purchases']:
        customer_id = purchase['customer_id']
        product_count = len(purchase['products'])

        # Update total products count for the customer
        if customer_id in total_products_per_customer:
            total_products_per_customer[customer_id] += product_count
        else:
            total_products_per_customer[customer_id] = product_count

    return total_products_per_customer

# Example usage
if __name__ == "__main__":
    bucket_name = 'your_bucket_name'
    file_key = 'your_file_key'
    aws_access_key_id = 'your_aws_access_key_id'
    aws_secret_access_key = 'your_aws_secret_access_key'
    
    purchase_data = fetch_purchase_data_from_s3(bucket_name, file_key, aws_access_key_id, aws_secret_access_key)
    if purchase_data:
        total_products_per_customer = calculate_total_products_per_customer(purchase_data)
        
        # Print total number of products purchased by each customer
        for customer_id, total_products in total_products_per_customer.items():
            print(f"Customer {customer_id}: {total_products} products purchased")
